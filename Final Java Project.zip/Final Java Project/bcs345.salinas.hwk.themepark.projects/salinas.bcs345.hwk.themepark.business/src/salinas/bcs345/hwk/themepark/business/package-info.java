/**
 * Contains Attraction, CalendarDate, DailyAttractionUsage and Park class data, which contain
 * a variety of different methods for each class. Also contains a ParkApplication class that provides
 * code in order for the Park GUI to function and to perform many different tasks.
 */
package salinas.bcs345.hwk.themepark.business;