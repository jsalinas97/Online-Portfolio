package salinas.bcs345.hwk.themepark.business;

import java.io.PrintStream;
import java.util.Scanner;

/** 
 * Class that contains methods to utilize private member variables
 * and their values to perform a variety of different tasks.
 * 
 * @author Joseph Salinas
 * @version 1.0
 * @since 2/24/17
 * 
 * */

public class CalendarDate {
	//Private member variables
	private int Month;
	private int Day;
	private int Year;
	//Public member variables
	//Get methods
	/**
	 * Get method for the Month private member variable, returns Month.
	 * 
	 * @return Month value is returned.
	 */
	public int getMonth()
	{
		
		return Month;
	}
	/**
	 * Get method for the Day private member variable, returns Day.
	 * 
	 * @return Day value is returned.
	 */
	public int getDay()
	{
		
		return Day;
	}
	/**
	 * Get method for the Year private member variable, returns Year.
	 * 
	 * @return Year value is returned.
	 */
	public int getYear()
	{
		
		return Year;
	}
	//Set methods
	/**
	 * Set method for Month private member variable, assigns passed-in variable value to
	 * the private member variable's new value.
	 * 
	 * @param newMonth New int value for Month.
	 */
	public void setMonth(int newMonth)
	{ 
		
		Month = newMonth;
	}
	/**
	 * Set method for Day private member variable, assigns passed-in variable value to
	 * the private member variable's new value.
	 * 
	 * @param newDay New int value for Day.
	 */
	public void setDay(int newDay)
	{
		
		Day = newDay;
	}
	/**
	 * Set method for Year private member variable, assigns passed-in variable value to
	 * the private member variable's new value.
	 * 
	 * @param newYear New int value for Year.
	 */
	public void setYear(int newYear)
	{
		
		Year = newYear;
	}
	/**
	 * Read method, reads in data from a passed in scanner variable.
	 * 
	 * @param s Scanner variable.
	 */
	public void Read(Scanner s){
		
		Month = s.nextInt();
		Day = s.nextInt();
		Year = s.nextInt();	
	}
	/**
	 * Write method, writes data to a file through a passed in scanner variable.
	 * 
	 * @param ps Scanner variable.
	 */
	public void Write(PrintStream ps)
	{
	
		ps.printf("%d\n%d\n%d", Month, Day, Year);	
	}
	/**
	 * getJSON method that returns a String value in JSON format.
	 * 
	 * @return Returns String in JSON format.
	 */
	public String getJSON()
	{
		
		String JSON;
		JSON = "{" + "\"month\"" + " " +  ":" + " " + Month + "," + " " + "\"day\"" + " " + ":" + " " + Day + "," + " " + "\"year\"" + " " + ":" + " " + Year + "}";
		return JSON;
	}
	/**
	 * toString method that returns a string with descriptive text.
	 * 
	 * @return s  String variable is returned.
	 */
	@Override
	public String toString() 
	{
		
		String s = Month + "/" + Day + "/" + Year;
		return s;
	}
	/**
	 * Overloaded constructor for the CalendarDate class.
	 * 
	 * @param n_Month Takes in new int value for Month.
	 * @param n_Day	 Takes in new int value for Day.
	 * @param n_Year Takes in new int value for Year.
	 */
	public CalendarDate(int n_Month, int n_Day, int n_Year)
	{
		
		Month = n_Month;
		Day = n_Day;
		Year = n_Year;
	}
	/**
	 * Default constructor for CalendarDate class.
	 */
	public CalendarDate()
	{
		
		Month = 0;
		Day = 0;
		Year = 0;	
	}

}
