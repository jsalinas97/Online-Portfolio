/**
 * Contains a Main class, DailyAttractionUsageConsoleUI class, ParkConsoleUI class and a ParkGraphicalUI class. 
 * Main contains code that will provide the user with a menu to select between the three user interfaces.
 */
package salinas.bcs345.hwk.themepark.presentation;