package salinas.bcs345.hwk.themepark.presentation;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.PrintStream;
import java.util.Scanner;


import salinas.bcs345.hwk.themepark.business.Park;

/**
 * This class provides the user with a menu, in which the user can select from
 * a variety of different tasks to perform.
 * 
 * @author Joseph Salinas
 * @version 1.0
 * @since 4/28/17
 *
 */
public class ParkConsoleUI {
	/**
	 * Method that presents the user with a menu of the Park UI, performs a variety of 
	 * different tasks.
	 * 
	 * @throws FileNotFoundException Throws FileNotFoundException.
	 */
	public void ShowUI() throws FileNotFoundException 
	{
		int choice = 0; //Variable used to hold choice value.
		Park park = new Park();
		Scanner keyboard = new Scanner(System.in);
		//Do-while loop will always provide the menu until the user decides to exit.
		do
		{
			
			System.out.println("Park UI");
			System.out.println("__________________________");
			System.out.println("1 - Read park info from file");
			System.out.println("2 - Write park info to file");
			System.out.println("3 - Show attraction by index");
			System.out.println("4 - Show max attraction usage");
			System.out.println("5 - Show park report on screen");
			System.out.println("6 - Show park as JSON string on screen");
			System.out.println("7 - Show park toString on screen");
			System.out.println("8 - Exit");
			System.out.println("Enter Choice:");
			choice = keyboard.nextInt();
			//While loop to check for a valid choice number, if choice number is invalid,
			//the user will have to re-enter their choice.
			while(choice > 8 || choice < 1)
			{
				System.out.println("Invalid choice, please enter a choice from 1-5:");
				choice = keyboard.nextInt();
			}
			keyboard.nextLine();
			switch(choice)
			{
				//Case 1 will call the Read method on the Park class.
				case 1:
						//Try-catch block to return the user to the main menu upon trying to read an invalid file,
						//prevents program from crashing, recovers by returning to main menu.
						try{
						
								System.out.println("Enter in a file name to read: ");
								String filename = keyboard.nextLine();
								Scanner reader = new Scanner(new FileReader(filename));
								park.Read(reader);
								break;
							}
						catch(FileNotFoundException x)
							{
					
								System.out.println("File could not be found, returning to main menu.");
								break;
							}
				//Case 2 Reads in a file name for the output, using the keyboard scanner and
				//passes PrintStream variable to the Write method.
				case 2:
						System.out.println("Enter in a file name to write out to:");
						String outfile = keyboard.nextLine();
						PrintStream ps = new PrintStream(outfile);
						park.Write(ps);
						break;
				//Case 3 will print out data for the specified index, if index is invalid
				//the exception will be handled.
				case 3:
						System.out.println("Please enter an index for the desired attraction:");
						int index = keyboard.nextInt();
						try
						{
							System.out.println("\nPurchase at index " + index + ":\n");
							System.out.println(park.GetByIndex(index));
						}
						catch (ArrayIndexOutOfBoundsException e)
						{
							
							System.err.println("\nInvalid index entered, ArrayIndexOutOfBoundsException caught.\n");
						}
						break;
				//Case 4 will print out the element with the highest customer usage.
				case 4:
						System.out.println("\nPurchase with highest customer usage:\n");
						System.out.println(park.GetMostDailyUsage());
						break;
				//Case 5 will write out the report.
				case 5:
						PrintStream printout = new PrintStream(System.out);
						park.Report(printout);
						break;
				//Case 6 will print out JSON format.
				case 6:
						System.out.println();
						System.out.println(park.getJSON());
						System.out.println();
						break;
				//Case 7 will print out toString format, with descriptive text.
				case 7:
						System.out.println();
						System.out.println(park.toString());
						System.out.println();
						break;
		}
			System.out.println();
			
		}while (choice != 8);
	}
}
	

