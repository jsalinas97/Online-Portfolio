package salinas.bcs345.hwk.themepark.presentation;

import javafx.application.Application;
import salinas.bcs345.hwk.themepark.business.ParkApplication;

/**
 * Class that contains a method to launch the ParkApplication.
 * 
 * @author Joseph Salinas
 * @version 1.0
 * @since 4/28/17
 *
 */
public class ParkGraphicalUI
{
	/**
	 * Launches the ParkAppplication.
	 */
	public void ShowUI()
	{
		Application.launch(ParkApplication.class);
	}
	
}
