﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization.Json;
using System.Runtime.Serialization;

namespace Lab_JSONClient
{

    [DataContract]
    public class Representative
    {
        [DataMember(Name = "name")]
        public string Name { get; set; }
        [DataMember(Name = "party")]
        public string Party { get; set; }
        [DataMember(Name = "state")]
        public string State { get; set; }
        [DataMember(Name = "district")]
        public string District { get; set; }
        [DataMember(Name = "phone")]
        public string Phone { get; set; }
        [DataMember(Name = "office")]
        public string Office { get; set; }
        [DataMember(Name = "link")]
        public string Link { get; set; }
    }
}
