﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Runtime.Serialization.Json;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Lab_JSONClient
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        RepresentativeList rl = new RepresentativeList();

        async void CallWebServicebutton_Click(object sender, RoutedEventArgs e)
        {
            HttpClient client = new HttpClient();
            HttpResponseMessage response = await client.GetAsync("https://whoismyrepresentative.com/getall_mems.php?zip=11735&output=json");

            string result = "";

            if (response.IsSuccessStatusCode)
            {
                result = await response.Content.ReadAsStringAsync();
                ResultTextBox.Text = result;

                //Put JSON string in Memory String.. needed for deserialization
                byte[] byteArray = Encoding.UTF8.GetBytes(result);
                MemoryStream stream = new MemoryStream(byteArray);

                DataContractJsonSerializer inputSerializer;
                inputSerializer = new DataContractJsonSerializer(typeof(RepresentativeList));

                rl = (RepresentativeList)inputSerializer.ReadObject(stream);

                ResultslistView.ItemsSource = rl.Representatives;

                stream.Close();


            }

            

           
        }
    }
}
