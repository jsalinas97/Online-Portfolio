﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace Lab_Task_Console
{
    class Program
    {
        public static void Main(string[] args)
        {
            Action act = delegate () { Message(); };
            Task t = new Task(act);
            t.Start();
            t.Wait();

            Console.WriteLine("Main finished.");

        }

        public static void Message()
        {
            Console.WriteLine("Hello, how are you?");
        }

    }
}
