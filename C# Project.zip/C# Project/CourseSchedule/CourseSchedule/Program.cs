﻿//***************************************************************
// File: Program.cs
//
// Purpose: Program.cs holds the Main method which displays
//          the user with a menu that can read either .xml
//          or .json files, write to either .xml or .json
//          files and display information from a specific class 
//          instance, all depending on the user's choice.
//
// Written By: Joseph Salinas
//
// Compiler: Visual Studio 2015
//
//***************************************************************
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Classes;
using System.Runtime.Serialization;
using System.IO;
using System.Runtime.Serialization.Json;


namespace CourseSchedule
{
    class Program
    {
        //**********************************************************
        // Method: Main
        //
        // Purpose: Provides the user with a menu driven console
        //          application that will read, write, and display
        //          information depending on the selected choice.
        //          
        //**********************************************************
        static void Main(string[] args)
        {
            //Creating a new instance of each collection.
            CourseCollection c = new CourseCollection();
            ProfessorCollection p = new ProfessorCollection();
            CourseMeetingCollection cm = new CourseMeetingCollection();
            RoomCollection r = new RoomCollection();
            int choice = 0;
            do
            {
                Console.WriteLine("Course Schedule Menu");
                Console.WriteLine("--------------------");
                Console.WriteLine("1 - Read CourseCollection from JSON file.");
                Console.WriteLine("2 - Read CourseCollection from XML file.");
                Console.WriteLine("3 - Write CourseCollection to JSON file.");
                Console.WriteLine("4 - Write CourseCollection to XML file.");
                Console.WriteLine("5 - Display CourseCollection Data on screen.");
                Console.WriteLine("6 - Show course data by id.");
                Console.WriteLine("7 - Read ProfessorCollection from JSON file.");
                Console.WriteLine("8 - Write ProfessorCollection to JSON file.");
                Console.WriteLine("9 - Display ProfessorCollection data on screen.");
                Console.WriteLine("10 - Read CourseMeetingCollection from JSON file.");
                Console.WriteLine("11 - Write CourseMeetingCollection to JSON file");
                Console.WriteLine("12 - Display CourseMeetingCollection data on screen");
                Console.WriteLine("13 - Exit");
                Console.Write("Enter Choice: ");
                choice = Convert.ToInt32(Console.ReadLine());

                #region Menu Items
                switch (choice)
                {
                    case 1:
                        Console.WriteLine();
                        //********************************************************************
                        //Prompts the user for a .json file name to read for CourseCollection 
                        //data, user will have to add the .json file extension at the end 
                        //of the filename.
                        //********************************************************************
                        Console.Write("Please enter the CourseCollection's .json file name: ");
                        string cFilename = Console.ReadLine();
                        //********************************************************************
                        //Uses a try-catch block in order to prevent the program from crashing 
                        //when the user enters an invalid file name.
                        //********************************************************************
                        try
                        {
                            //Using cReader and cInput to Deseralize the specified .json file.
                            FileStream cReader = new FileStream(cFilename, FileMode.Open, FileAccess.Read);
                            DataContractJsonSerializer cInput;
                            cInput = new DataContractJsonSerializer(typeof(CourseCollection));
                            c = (CourseCollection)cInput.ReadObject(cReader);
                            cReader.Close();
                        }
                        catch(FileNotFoundException e)
                        {
                            Console.WriteLine("File name entered not found.");
                        }
                        Console.WriteLine();
                        break;
                    case 2:
                        Console.WriteLine();
                        //********************************************************************
                        //Prompts the user for a .json file name to read for CourseCollection 
                        //data, user will have to add the .xml file extension at the end 
                        //of the filename.
                        //********************************************************************
                        Console.Write("Please enter the CourseCollection's .xml file name: ");
                        string cxmlFilename = Console.ReadLine();
                        //********************************************************************
                        //Uses a try-catch block in order to prevent the program from crashing 
                        //when the user enters an invalid file name.
                        //********************************************************************
                        try
                        {
                            //Using cxmlReader and cxmlInput to Deseralize the specified .xml file.
                            FileStream cxmlReader = new FileStream(cxmlFilename, FileMode.Open, FileAccess.Read);
                            DataContractSerializer cxmlInput;
                            cxmlInput = new DataContractSerializer(typeof(CourseCollection));
                            c = (CourseCollection)cxmlInput.ReadObject(cxmlReader);
                            cxmlReader.Close();
                        }
                        catch(FileNotFoundException e)
                        {
                            Console.WriteLine("File name entered not found.");
                        }
                        Console.WriteLine();
                        break;
                    case 3:
                        Console.WriteLine();
                        //********************************************************************
                        //Prompts the user for a .json file name to write CourseCollection 
                        //data to, user will have to add the .json file extension at the end 
                        //of the filename.
                        //********************************************************************
                        Console.Write("Please enter a name for the new .json file: ");
                        string cOutFileName = Console.ReadLine();
                        //Using cWriter and cSer to Seralize the specified .json file.
                        FileStream cWriter = new FileStream(cOutFileName, FileMode.Create, FileAccess.Write);
                        DataContractJsonSerializer cSer;
                        cSer = new DataContractJsonSerializer(typeof(CourseCollection));
                        cSer.WriteObject(cWriter, c);
                        cWriter.Close();
                        Console.WriteLine();
                        break;
                    case 4:
                        //********************************************************************
                        //Prompts the user for a .xml file name to write CourseCollection 
                        //data to, user will have to add the .xml file extension at the end 
                        //of the filename.
                        //********************************************************************
                        Console.WriteLine();
                        Console.Write("Please enter a name for the new .xml file: ");
                        string cxmlOutFileName = Console.ReadLine();
                        //Using cxmlWriter and cxmlSer to Seralize the specified .xml file.
                        FileStream cxmlWriter = new FileStream(cxmlOutFileName, FileMode.Create, FileAccess.Write);
                        DataContractSerializer cxmlSer;
                        cxmlSer = new DataContractSerializer(typeof(CourseCollection));
                        cxmlSer.WriteObject(cxmlWriter, c);
                        cxmlWriter.Close();
                        Console.WriteLine();
                        break;
                    case 5:
                        //Prints out CoureCollection Data to the screen.
                        Console.WriteLine();
                        Console.WriteLine("CourseCollection Data");
                        Console.WriteLine("---------------------");
                        Console.WriteLine(c.ToString());
                        break;
                    case 6:
                        //******************************************************
                        //Performs a search on CourseCollection data, displaying
                        //the instance having the matching ID.
                        //******************************************************
                        Console.WriteLine();
                        Console.Write("Please enter an ID number to search for: ");
                        int num = Convert.ToInt32(Console.ReadLine());
                        Console.WriteLine();
                        Console.WriteLine("Course Data for ID : " + num);
                        Console.WriteLine("--------------------------");
                        //****************************************************************
                        //Prints out the CourseCollection instance containing the matching
                        //ID, will print nothing if there is no match found.
                        //****************************************************************
                        if (c.Find(num) == null)
                        {
                            Console.WriteLine("No records found for the ID provided, null value returned.");
                            Console.WriteLine();
                        }
                        else
                        {
                            Console.WriteLine(c.Find(num));
                        }
                        break;
                    case 7:
                        Console.WriteLine();
                        //**********************************************************************
                        //Prompts the user for a .json file name to read for ProfessorCollection 
                        //data, user will have to add the .json file extension at the end 
                        //of the filename.
                        //**********************************************************************
                        Console.Write("Please enter the ProfessorCollection's .json file name: ");
                        //********************************************************************
                        //Uses a try-catch block in order to prevent the program from crashing 
                        //when the user enters an invalid file name.
                        //********************************************************************
                        try
                        {
                            //Using pReader and pInput to Deseralize the specified .json file.
                            string pFilename = Console.ReadLine();
                            FileStream pReader = new FileStream(pFilename, FileMode.Open, FileAccess.Read);
                            DataContractJsonSerializer pInput;
                            pInput = new DataContractJsonSerializer(typeof(ProfessorCollection));
                            p = (ProfessorCollection)pInput.ReadObject(pReader);
                            pReader.Close();
                            Console.WriteLine();
                        }
                        catch(FileNotFoundException e)
                        {
                            Console.WriteLine("File name entered was not found.");
                        }
                        break;
                    case 8:
                        Console.WriteLine();
                        //********************************************************************
                        //Prompts the user for a .json file name to write ProfessorCollection 
                        //data to, user will have to add the .json file extension at the end 
                        //of the filename.
                        //********************************************************************
                        Console.Write("Please enter a name for the new .json file: ");
                        string pOutFileName = Console.ReadLine();
                        //Using pWriter and pSer to Seralize the specified .json file.
                        FileStream pWriter = new FileStream(pOutFileName, FileMode.Create, FileAccess.Write);
                        DataContractJsonSerializer pSer;
                        pSer = new DataContractJsonSerializer(typeof(ProfessorCollection));
                        pSer.WriteObject(pWriter, p);
                        pWriter.Close();
                        break;
                    case 9:
                        //Prints out ProfessorCollection Data to the screen.
                        Console.WriteLine();
                        Console.WriteLine("ProfessorCollection Data");
                        Console.WriteLine("------------------------");
                        Console.WriteLine(p.ToString());
                        break;
                    case 10:
                        Console.WriteLine();
                        //**************************************************************************
                        //Prompts the user for a .json file name to read for CourseMeetingCollection 
                        //data, user will have to add the .json file extension at the end 
                        //of the filename.
                        //**************************************************************************
                        Console.Write("Please enter the CourseMeetingCollection .json file name: ");
                        string cmFilename = Console.ReadLine();
                        FileStream cmReader;
                        //********************************************************************
                        //Uses a try-catch block in order to prevent the program from crashing 
                        //when the user enters an invalid file name.
                        //********************************************************************
                        try
                        {
                            //Using cmReader and cmInput to Deseralize the specified .json file.
                            cmReader = new FileStream(cmFilename, FileMode.Open, FileAccess.Read);
                            DataContractJsonSerializer cmInput;
                            cmInput = new DataContractJsonSerializer(typeof(CourseMeetingCollection));
                            cm = (CourseMeetingCollection)cmInput.ReadObject(cmReader);
                            cmReader.Close();
                        }
                        catch(FileNotFoundException e)
                        {
                            Console.WriteLine("File name entered was not found.");
                                   
                        }
                        Console.WriteLine();
                        break;
                    case 11:
                        Console.WriteLine();
                        //***********************************************************************
                        //Prompts the user for a .json file name to write CourseMeetingCollection 
                        //data to, user will have to add the .json file extension at the end 
                        //of the filename.
                        //***********************************************************************
                        Console.Write("Please enter a name for the new .json file: ");
                        string cmOutFileName = Console.ReadLine();
                        //Using cmWriter and cmSer to Seralize the specified .json file.
                        FileStream cmWriter = new FileStream(cmOutFileName, FileMode.Create, FileAccess.Write);
                        DataContractJsonSerializer cmSer;
                        cmSer = new DataContractJsonSerializer(typeof(CourseMeetingCollection));
                        cmSer.WriteObject(cmWriter, cm);
                        cmWriter.Close();
                        Console.WriteLine();
                        break;
                    case 12:
                        //Prints out CourseMeetingCollection Data to the screen.
                        Console.WriteLine();
                        Console.WriteLine("CourseMeetingCollection Data");
                        Console.WriteLine("----------------------------");
                        Console.WriteLine(cm.ToString());
                        break;
                    case 13:
                        break;
                    default:
                        //If the choice entered is not displayed on the menu, the user wil receive an error message.
                        Console.WriteLine("Invalid choice was entered, please select from the options above.");
                        Console.WriteLine();
                        break;  
                }
                #endregion
            }
            while (choice != 13);
        }
    }
        }
