﻿//**************************************************************************
// File: MainWindow.xaml.cs
//
// Purpose: Contains the MainWindow partial class, automatically listens
//          for an Addcourse event. Performs actions such as firing an
//          Addcourse event, initializing the DataLayer, and displaying
//          all data within the DataLayer.
//          
//          
// Written By: Joseph Salinas
//
// Compiler: Visual Studio 2015
//
//*************************************************************************
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Classes;

namespace CourseWPF
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {

        public DataLayer d = new DataLayer();

        #region Methods
        //************************************************************************
        //Method: MainWindow
        //
        //Purpose: Default constructor, "listens" for when data is added.
        //************************************************************************
        public MainWindow()
        {
            InitializeComponent();
            d.CourseAdded += WindowEventHandler;
        }
        //************************************************************************
        //Method: WindowEventHandler
        //
        //Purpose: Acts as the event handler for DataLayer class' AddCourse event
        //************************************************************************
        public void WindowEventHandler(Object sender, DataLayer.AddCourseCollectionEventArgs evtArgs)
        {
            MessageBox.Show(evtArgs.courseAdded.n_ID + ", " + evtArgs.courseAdded.n_Designator + ", " +
                evtArgs.courseAdded.n_Number + ", " + evtArgs.courseAdded.n_Title + ", " + evtArgs.courseAdded.n_Description +
                ", " + evtArgs.courseAdded.n_Credits);
        }
        //************************************************************************
        //Method: buttonReadData_Click
        //
        //Purpose: Proccesses the button click event, which will initialize the
        //         Data Layer, by seralizing data from multiple json files.
        //************************************************************************
        private void buttonReadData_Click(object sender, RoutedEventArgs e)
        {
            d.Initialize();
            MessageBox.Show("Data sucessfully read.");
        }
        //************************************************************************
        //Method: buttonShowData_Click
        //
        //Purpose: Proccesses the button click event, which will show all the 
        //         data contained in the Data Layer.
        //************************************************************************
        private void buttonShowData_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show(d.ToString());
        }
        //************************************************************************
        //Method: buttonAddData_Click
        //
        //Purpose: Proccesses the button click event, which will create a new 
        //         instance of Course, and will take values from the TextBoxes
        //         to assign to the member variables of the instance. Then the
        //         instance will be passed into the DataLayer's AddCourse method.
        //************************************************************************
        private void buttonAddCourse_Click(object sender, RoutedEventArgs e)
        {
            //*************************************************************
            //Uses a try-catch block in order to catch a FormatException,
            //if the user inputs a string for an int value by mistake,
            //instead of having the program crash the user will be warned.
            //*************************************************************
            try
            {
                Course c = new Course();
                c.n_ID = Convert.ToInt32(textBoxId.Text);
                c.n_Description = textBoxDescription.Text;
                c.n_Designator = textBoxDesignator.Text;
                c.n_Number = textBoxNumber.Text;
                c.n_Title = textBoxTitle.Text;
                c.n_Credits = Convert.ToInt32(textBoxCredits.Text);
                d.AddCourse(c);
                //Clears the textboxes, preparing for the next entry.
                textBoxCredits.Text = "";
                textBoxDescription.Text = "";
                textBoxDesignator.Text = "";
                textBoxId.Text = "";
                textBoxTitle.Text = "";
                textBoxNumber.Text = "";
            }
            catch (FormatException exc)
            {
                MessageBox.Show("Invalid entry.");
                //Clears the textboxes, preparing for the next entry.
                textBoxCredits.Text = "";
                textBoxDescription.Text = "";
                textBoxDesignator.Text = "";
                textBoxId.Text = "";
                textBoxTitle.Text = "";
                textBoxNumber.Text = "";
            }
        }
        #endregion
    }
}
