﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab_Interfaces
{
    public class VideoGameInfo : IDisplay, IFileOperations
    {
        private string name;
        private string platform;
        private double price;
        private StreamWriter sw;

        public VideoGameInfo()
        {
            name = "Null";
            platform = "Unknown";
            price = 0;

        }

        public void Show()
        {
            Console.WriteLine("Name: " + name);
            Console.WriteLine("Platform: " + platform);
            Console.WriteLine("Price: " + price);
        }

        public void Open(string filename)
        {
            sw = new StreamWriter(filename);
        }

        public void Save()
        { 
            sw.WriteLine("Name: " + name);
            sw.WriteLine("Platform: " + platform);
            sw.WriteLine("Price: " + price);
            sw.Flush();
        }

        public string n_name
        {
            get
            {
                return name;
            }
            set
            {
                name = value;
            }
        }

        public string n_platform
        {
            get
            {
                return platform;
            }
            set
            {
                platform = value;
            }
        }

        public double n_price
        {
            get
            {
                return price;
            }
            set
            {
                price = value;
            }
        }




    }
}
