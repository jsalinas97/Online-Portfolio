﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace Lab_Interfaces
{
    class Program
    {
        static void Main(string[] args)
        {
            VideoGameInfo vg = new VideoGameInfo();

            IDisplay d = vg;
            IFileOperations f = vg;

            vg.n_name = "Microsoft";
            vg.n_platform = "Windows";
            vg.n_price = 59.99;

                   /*     vg.Open("VGInformation.txt");

                        vg.Save();
                        vg.Show();

                */
            
            f.Open("VGInfo.txt");
            f.Save();
            d.Show();
 

        }
    }
}
