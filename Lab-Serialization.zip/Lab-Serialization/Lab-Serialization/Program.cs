﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.Serialization.Json;
using System.Text;
using System.Threading.Tasks;

namespace Lab_Serialization
{
    class Program
    {
        static void Main(string[] args)
        {
            //Working Address
            Address a = new Address();

            a.n_city = "Farmingdale";
            a.n_state = "New York";

            string filename = "Address.json";

            FileStream filewriter = new FileStream(filename, FileMode.Create, FileAccess.Write);

            DataContractJsonSerializer ser;

            ser = new DataContractJsonSerializer(typeof(Address));

            ser.WriteObject(filewriter, a);
            filewriter.Close();

            Address a2 = new Address();

            FileStream reader = new FileStream(filename, FileMode.Open, FileAccess.Read);

            DataContractJsonSerializer input;
            input = new DataContractJsonSerializer(typeof(Address));

            a2 = (Address)input.ReadObject(reader);
            reader.Close();

            Console.WriteLine(a2.ToString()); //Works

            Person p = new Person();

            string personfile = "Person.json";
            p.n_address.n_city = "Farmingdale";
            p.n_address.n_state = "New York";
            p.n_first = "Joseph";
            p.n_last = "Salinas";
            p.n_age = 20;

            FileStream pwriter = new FileStream(personfile, FileMode.Create, FileAccess.Write);

            DataContractJsonSerializer personser;

            personser = new DataContractJsonSerializer(typeof(Person));

            personser.WriteObject(pwriter, p);
            pwriter.Close();

            Console.WriteLine(p.ToString()); //Works

            Person p2 = new Person();

            FileStream preader = new FileStream(personfile, FileMode.Open, FileAccess.Read);

            DataContractJsonSerializer pinput;
            pinput = new DataContractJsonSerializer(typeof(Person));

            p2 = (Person)pinput.ReadObject(preader);
            preader.Close();

            Console.WriteLine(p2.ToString());


        }
    }
}
