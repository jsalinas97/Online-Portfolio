﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace Lab_Serialization
{
    [DataContract]
    class Person
    {
        private string first;
        private string last;
        private int age;
        private Address address;

        public Person()
        {
            address = new Address();
        }
        

        [DataMember(Name = "first")]
        public string n_first
        {
            get
            {
                return first;
            }

            set
            {
                first = value;
            }
        }

        [DataMember(Name = "last")]
        public string n_last
        {
            get
            {
                return last;
            }

            set
            {
                last = value;
            }
        }
        
        [DataMember(Name = "address")]
        public Address n_address
        {
            get
            {
                return address;
            }
            set
            {
                address = value;
            }

        }

        [DataMember(Name = "age")]
        public int n_age
        {
            get
            {
                return age;
            }
            set
            {
                age = value;
            }

        }

        public override string ToString()
        {
            return first + " " + last + " " + age + " " + address.n_city + " " + address.n_state;
        }



    }
}
