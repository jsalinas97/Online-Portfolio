﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;


namespace Lab_Serialization
{
    [DataContract]
    class Address
    {
 
        private string city;
        
        private string state;

        [DataMember(Name = "city")]
        public string n_city
        {
            get
            {
                return city;
            }
            set
            {
                city = value;
            }
        }

        [DataMember(Name = "state")]
        public string n_state
        {
            get
            {
                return state;
            }
            set
            {
                state = value;
            }
        }

        public override string ToString()
        {
            return city + " " + state;

        }

    }
}
